<?php

// Swiss QR payload builder + debug helper
// This file expects $OrderRow, $bankaRow, $cariRow and $Currency to be set by caller.
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel;

$debugLog = __DIR__ . '/taslak/qrcode_debug.log';
@mkdir(dirname($debugLog), 0755, true);
function qr_log($msg) {
    global $debugLog;
    $time = date('Y-m-d H:i:s');
    @file_put_contents($debugLog, "[$time] $msg\n", FILE_APPEND);
}

// Basic sanity checks
if (!isset($OrderRow) || !is_array($OrderRow)) {
    qr_log('ERROR: $OrderRow is not set or not an array');
    return;
}
if (!isset($bankaRow) || !is_array($bankaRow)) {
    qr_log('ERROR: $bankaRow is not set or not an array');
    return;
}
if (!isset($cariRow) || !is_array($cariRow)) {
    qr_log('ERROR: $cariRow is not set or not an array');
    return;
}

// Prepare values
$ToplamTutar = function_exists('mony') ? mony($OrderRow['ToplamTutar']) : number_format((float)$OrderRow['ToplamTutar'], 2, '.', '');
$ToplamTutar = str_replace(',', '', $ToplamTutar);
$Iban = isset($bankaRow['BankaIBAN']) ? str_replace([' ', "\n", "\r"], '', $bankaRow['BankaIBAN']) : '';
$Iban = trim($Iban);

// Determine reference: prefer OrderCode but fall back to several common fields if missing
$Reference = '';
$ReferenceField = null;
$refCandidates = ['OrderCode','OrderID','ID','SiparisNo','SiparisKodu'];
foreach ($refCandidates as $f) {
    if (isset($OrderRow[$f]) && trim((string)$OrderRow[$f]) !== '') {
        $Reference = trim((string)$OrderRow[$f]);
        $ReferenceField = $f;
        break;
    }
}

if ($Reference !== '') {
    $RefType = 'SCOR';
    $RefValue = 'RF' . $Reference;
    qr_log("Using reference field '$ReferenceField' => $Reference");
} else {
    $RefType = 'NON';
    $RefValue = '';
    qr_log('No reference field found in OrderRow; QR will use NON');
}

// Write a small meta/debug file (won't affect QR payload) so we can inspect on the server
$meta = [
    'time' => date('c'),
    'reference_field' => $ReferenceField,
    'reference_value' => $Reference,
    'order_keys' => array_keys($OrderRow),
];
$metaPath = __DIR__ . '/taslak/qrcode_meta.txt';
@file_put_contents($metaPath, print_r($meta, true));
qr_log("Wrote meta to $metaPath");
// If no reference found in OrderRow, try using $OrderCode (set by order_pdf.php from GET id)
if ($Reference === '' && isset($OrderCode) && trim((string)$OrderCode) !== '') {
    $Reference = trim((string)$OrderCode);
    $ReferenceField = 'GET.id_or_OrderCode_var';
    $RefType = 'SCOR';
    $RefValue = 'RF' . $Reference;
    qr_log("Fallback: using \$OrderCode variable as reference => $Reference");
    // update meta
    $meta['reference_field'] = $ReferenceField;
    $meta['reference_value'] = $Reference;
    @file_put_contents($metaPath, print_r($meta, true));
    qr_log("Updated meta with fallback reference to $metaPath");
}

// Build Swiss QR payload according to expected layout using an array of lines
$lines = [];
$lines[] = 'SPC';
$lines[] = '0200';
$lines[] = '1';
$lines[] = $Iban;
$lines[] = 'S';
$lines[] = isset($bankaRow['BankaUser']) ? $bankaRow['BankaUser'] : '';
$lines[] = isset($bankaRow['BankaAdres']) ? $bankaRow['BankaAdres'] : '';
$lines[] = isset($bankaRow['BankaAdres2']) ? $bankaRow['BankaAdres2'] : '';
$lines[] = isset($bankaRow['BankaPostaKodu']) ? $bankaRow['BankaPostaKodu'] : '';
$lines[] = isset($bankaRow['BankaCity']) ? $bankaRow['BankaCity'] : '';
$lines[] = 'CH';
// creditor additional empty address lines per layout
for ($i = 0; $i < 6; $i++) { $lines[] = ''; }
$lines[] = $ToplamTutar;
$lines[] = $Currency;
$lines[] = 'S';
$lines[] = trim(($cariRow['CariUnvan'] ?? '') . ' ' . ($cariRow['CariName'] ?? '') . ' ' . ($cariRow['CariSurname'] ?? ''));
$lines[] = $cariRow['CariAdres'] ?? '';
$lines[] = $cariRow['CariAdres2'] ?? '';
$lines[] = $cariRow['CariPostakodu'] ?? '';
$lines[] = $cariRow['CariCity'] ?? '';
$lines[] = 'CH';

// Reference block: insert either NON or SCOR + value
if (!empty($RefType) && $RefType === 'NON') {
    $lines[] = 'NON';
    $lines[] = '';
    $lines[] = '';
} else {
    $lines[] = $RefType;
    $lines[] = $RefValue;
    $lines[] = '';
}

$lines[] = 'EPD';
$QRCODE = implode("\n", $lines) . "\n";
qr_log("Constructed QRCODE with RefType={$RefType} RefValue={$RefValue}");

// Write payload to file for debugging
$payloadPath = __DIR__ . '/taslak/qrcode_payload.txt';
@mkdir(dirname($payloadPath), 0755, true);
if (@file_put_contents($payloadPath, $QRCODE) === false) {
    qr_log("ERROR: failed to write payload to $payloadPath");
} else {
    qr_log("Payload written to $payloadPath");
}

// If debug flag present, output payload to browser and stop (quick check for reference)
if (isset($_GET['debug_qr']) && $_GET['debug_qr']) {
    header('Content-Type: text/plain; charset=utf-8');
    echo $QRCODE;
    qr_log('debug_qr output to browser');
    exit;
}

// Ensure output dir exists and is writable
@mkdir(__DIR__ . '/taslak', 0755, true);

// Build QR image using Endroid
try {
    $result = Builder::create()
        ->data($QRCODE)
        ->encoding(new Encoding('UTF-8'))
        ->errorCorrectionLevel(ErrorCorrectionLevel::High)
        ->size(400)
        ->margin(-2)
        ->logoPath(__DIR__.'/taslak/logo.png')
        ->logoResizeToWidth(50)
        ->logoPunchoutBackground(true)
        ->validateResult(false)
        ->build();
    qr_log('Builder::build() succeeded');
} catch (\Throwable $e) {
    qr_log('Exception building QR: ' . $e->getMessage());
    qr_log($e->getTraceAsString());
    @file_put_contents(__DIR__ . '/taslak/qrcode_error.txt', $e->getMessage());
    return;
}

// Save PNG
$pngPath = __DIR__ . '/taslak/qrcode.png';
try {
    $result->saveToFile($pngPath);
    qr_log("QR image saved to: $pngPath");
} catch (\Throwable $e) {
    qr_log('Exception saving PNG: ' . $e->getMessage());
    @file_put_contents(__DIR__ . '/taslak/qrcode_error.txt', $e->getMessage());
}

