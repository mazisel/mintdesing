<?php
// Reduce noisy deprecation warnings from vendor libs when running tests
error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED);
ini_set('display_errors', '1');
// Test script to generate QR using existing order_qrcode.php logic
// Usage: place this file in the project and run via PHP (php view/app/test_qr.php)

$autoload = __DIR__ . '/../../config/vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
}

// Minimal replacements for environment variables used by order_qrcode.php
// Provide sample data (you can modify these values to match a real order)
$OrderRow = [
    'OrderID' => 123,
    'OrderCode' => '20251005-123',
    'ToplamTutar' => 150.75,
    'OrderUrun' => json_encode([]),
    'OrderDate' => date('Y-m-d'),
];
$bankaRow = [
    'BankaIBAN' => 'CH93 0076 2011 6238 5295 7',
    'BankaUser' => 'Example Bank',
    'BankaAdres' => 'Bahnhofstrasse 1',
    'BankaAdres2' => 'Suite 100',
    'BankaPostaKodu' => '8001',
    'BankaCity' => 'Zürich'
];
$cariRow = [
    'CariUnvan' => 'ACME GmbH',
    'CariName' => 'Max',
    'CariSurname' => 'Muster',
    'CariAdres' => 'Musterstrasse 5',
    'CariAdres2' => '',
    'CariPostakodu' => '8000',
    'CariCity' => 'Zürich'
];
// Currency used in view (order_qrcode.php expects $Currency possibly set)
$Currency = 'CHF';

// Provide a simple mony() fallback if not defined
if (!function_exists('mony')) {
    function mony($v, $currency = null) {
        return number_format((float)$v, 2, '.', '');
    }
}
// Build payload (same logic as order_qrcode.php) and write to a payload file for inspection
$ToplamTutar = mony($OrderRow['ToplamTutar']);
$ToplamTutar = str_replace(',', '', $ToplamTutar);
$Iban = str_replace(' ', '', $bankaRow['BankaIBAN']);
$Iban = str_replace(["\n","\r"], '', $Iban);
$Iban = trim($Iban);

$Reference = '';
if (!empty($OrderRow['OrderCode'])) {
    $Reference = trim($OrderRow['OrderCode']);
}
if ($Reference !== '') {
    $RefType = 'SCOR';
    $RefValue = 'RF' . $Reference;
} else {
    $RefType = 'NON';
    $RefValue = '';
}

$QRCODE = "SPC\n0200\n1\n{$Iban}\nS\n{$bankaRow['BankaUser']}\n{$bankaRow['BankaAdres']}\n{$bankaRow['BankaAdres2']}\n{$bankaRow['BankaPostaKodu']}\n{$bankaRow['BankaCity']}\nCH\n\n\n\n\n\n\n{$ToplamTutar}\n{$Currency}\nS\n{$cariRow['CariUnvan']} {$cariRow['CariName']} {$cariRow['CariSurname']}\n{$cariRow['CariAdres']}\n{$cariRow['CariAdres2']}\n{$cariRow['CariPostakodu']}\n{$cariRow['CariCity']}\nCH\nNON\n\n\nEPD\n";
$QRCODE = str_replace("\nNON\n\n\nEPD\n", "\n{$RefType}\n{$RefValue}\n\nEPD\n", $QRCODE);

$payloadPath = __DIR__ . '/taslak/qrcode_payload.txt';
@mkdir(dirname($payloadPath), 0755, true);
file_put_contents($payloadPath, $QRCODE);
echo "Payload written to: $payloadPath\n";

// If Endroid exists, try to include order_qrcode.php to build PNG
if (class_exists('Endroid\\QrCode\\Builder\\Builder')) {
    include __DIR__ . '/order_qrcode.php';
    $png = __DIR__ . '/taslak/qrcode.png';
    if (file_exists($png)) {
        echo "QR image generated at: $png\n";
    } else {
        echo "Tried to build PNG but it was not created.\n";
    }
} else {
    echo "Endroid QR library not available. To generate PNG, install dependencies (composer) and re-run this script.\n";
}

?>